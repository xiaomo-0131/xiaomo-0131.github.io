# Editorial Serif 字体

- Typeface: Noto Serif SC, Google Fonts v36.
- Copyright: (c) 2017–2024 Adobe (http://www.adobe.com/).
- License: SIL Open Font License 1.1, see `OFL.txt`.
- Source CSS: https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@400;600&display=swap
- Upstream license: https://raw.githubusercontent.com/notofonts/noto-cjk/main/Serif/LICENSE
- Weights: 400 (Regular) and 600 (SemiBold).
- Font files are self-hosted; runtime rendering makes no Google Fonts requests.
- WOFF2 files are Unicode subsets for the current article corpus, site interface, ASCII, and punctuation. Glyph designs were not altered. New characters outside this subset fall back to the system serif font until the subset is rebuilt.
- CSS family alias: `Editorial Serif`.
- Full source fonts and the repeatable subset build script are retained at `work/editorial-redesign/fonts-source/` in the project workspace.
